
public class Work3 {
	public static void main(String args[])
	{
		 int score[] = {3, 5, 15, 2, 9, 10, 85, 100,78, 45};
         for (int i = 0; i < score.length -1; i++)
         {    //�����n-1������
             for(int j = 0 ;j < score.length - i - 1; j++)
             {   
                 if(score[j] > score[j + 1])
                 {    //�Ѵ��ֵ����������
                     int temp = score[j];
                     score[j] = score[j + 1];
                     score[j + 1] = temp;
                 }
             }     
         }
             for(int a = 0; a < score.length; a++){
                 System.out.print(score[a] + "\t");
        }
		}
	}